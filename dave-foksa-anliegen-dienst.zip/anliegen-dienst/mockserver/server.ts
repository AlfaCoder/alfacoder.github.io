import cors from "cors";
import express, { Request, Response } from "express";
import { Anliegen } from "./../libs/api/model/anliegen";

const port = 3000;
const app = express();

app.use(cors());
app.use(express.json());

app.get("/anliegen/:userId", (req: Request, res: Response) => {
  const userId = req.params.userId;
  const heute = new Date();
  const aenderungsDatum = heute.toISOString();

  let date = new Date();
  date.setMonth(heute.getMonth() - 1);
  const erstellungsDatum = date.toISOString();

  const anliegenListe: Anliegen[] = [
    {
      id: "000a001a-1234-456e-9876-f123w123w412",
      status: "in_bearbeitung",
      typ: "Rehabilitationsantrag",
      aenderungsDatum: aenderungsDatum,
      erstellungsDatum: erstellungsDatum,
      fertigstellungsDatum: "",
    },
    {
      id: "000a002a-1234-456e-9876-f123w123w412",
      status: "abgeschlossen",
      typ: "Rentenantrag",
      aenderungsDatum: aenderungsDatum,
      erstellungsDatum: erstellungsDatum,
      fertigstellungsDatum: aenderungsDatum,
    },
  ];

  console.error(userId);
  res.status(200).json({ items: anliegenListe });
});

app.listen(port, () => console.log(`DRV MockServer listening on port ${port}`));
