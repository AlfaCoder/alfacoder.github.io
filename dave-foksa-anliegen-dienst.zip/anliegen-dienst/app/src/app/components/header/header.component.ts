import { Component } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { MatToolbar } from '@angular/material/toolbar';

@Component({
  selector: 'app-header',
  imports: [MatButton, MatIcon, MatToolbar],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class Header {}
