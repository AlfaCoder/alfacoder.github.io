import { Component } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatToolbar } from '@angular/material/toolbar';
import { version } from '../../../../package.json';

@Component({
  selector: 'app-footer',
  imports: [MatButton, MatToolbar],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.scss',
})
export class Footer {
  public version = `v${version}`;
}
