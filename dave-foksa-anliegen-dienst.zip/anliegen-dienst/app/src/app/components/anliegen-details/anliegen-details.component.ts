import { Component } from '@angular/core';

@Component({
  selector: 'app-anliegen-details',
  imports: [],
  templateUrl: './anliegen-details.component.html',
})
export class AnliegenDetailsComponent {}
