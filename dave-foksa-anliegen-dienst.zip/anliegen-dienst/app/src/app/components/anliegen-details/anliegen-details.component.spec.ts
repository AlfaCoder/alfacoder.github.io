import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnliegenDetailsComponent } from './anliegen-details.component';

describe('AnliegenUebersicht', () => {
  let component: AnliegenDetailsComponent;
  let fixture: ComponentFixture<AnliegenDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AnliegenDetailsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AnliegenDetailsComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
