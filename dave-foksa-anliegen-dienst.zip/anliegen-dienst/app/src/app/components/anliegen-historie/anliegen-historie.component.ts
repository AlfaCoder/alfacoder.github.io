import { Component } from '@angular/core';

@Component({
  selector: 'app-anliegen-historie',
  imports: [],
  templateUrl: './anliegen-historie.component.html',
})
export class AnliegenHistorieComponent {}
