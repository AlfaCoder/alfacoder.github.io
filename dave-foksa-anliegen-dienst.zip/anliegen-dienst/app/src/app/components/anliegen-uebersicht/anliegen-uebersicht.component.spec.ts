import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnliegenUebersichtComponent } from './anliegen-uebersicht.component';

describe('AnliegenUebersicht', () => {
  let component: AnliegenUebersichtComponent;
  let fixture: ComponentFixture<AnliegenUebersichtComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AnliegenUebersichtComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AnliegenUebersichtComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
