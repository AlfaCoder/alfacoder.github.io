import { Component } from '@angular/core';

@Component({
  selector: 'app-anliegen-uebersicht',
  imports: [],
  templateUrl: './anliegen-uebersicht.component.html',
  styleUrl: './anliegen-uebersicht.component.scss',
})
export class AnliegenUebersichtComponent {}
