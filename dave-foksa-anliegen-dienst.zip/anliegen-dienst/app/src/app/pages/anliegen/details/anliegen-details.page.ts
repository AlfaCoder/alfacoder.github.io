import { Component } from '@angular/core';
import { AnliegenHistorieComponent } from '../../../components/anliegen-historie/anliegen-historie.component';
import { AnliegenDetailsComponent } from './../../../components/anliegen-details/anliegen-details.component';

@Component({
  selector: 'app-anliegen-details',
  imports: [AnliegenDetailsComponent, AnliegenHistorieComponent],
  templateUrl: './anliegen-details.page.html',
})
export default class AnliegenDetailsPage {}
