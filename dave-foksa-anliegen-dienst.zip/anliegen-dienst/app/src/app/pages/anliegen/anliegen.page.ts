import { Component } from '@angular/core';

@Component({
  selector: 'app-anliegen',
  imports: [],
  templateUrl: './anliegen.page.html',
})
export default class AnliegenPage {}
