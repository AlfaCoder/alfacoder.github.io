import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';
import { Anliegen } from '../../../../../libs/api/model/anliegen';
import { AnliegenListe } from '../../../../../libs/api/model/anliegen-liste';
import { AnliegenUebersichtComponent } from '../../components/anliegen-uebersicht/anliegen-uebersicht.component';
import { DefaultApiService } from './../../../../../libs/api/api/default.service';

@Component({
  selector: 'app-startseite',
  imports: [AnliegenUebersichtComponent],
  templateUrl: './startseite.page.html',
  styleUrl: './startseite.page.scss',
})
export class StartseitePage implements OnInit {
  private readonly api: DefaultApiService = inject(DefaultApiService);
  private readonly http: HttpClient = inject(HttpClient);

  ngOnInit(): void {
    const fakeUserId = '123b785a-1234-456e-9876-f123w123w412';
    this.api.getAnliegenListe(fakeUserId).subscribe((anliegen: AnliegenListe) => {
      anliegen.items.forEach((anliegen: Anliegen) => {
        console.log(anliegen);
      });
    });
  }
}
