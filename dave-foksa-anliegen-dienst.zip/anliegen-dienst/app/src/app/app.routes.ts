import { Routes } from '@angular/router';
import { StartseitePage } from './pages/startseite/startseite.page';

export const routes: Routes = [
  {
    path: '',
    component: StartseitePage,
  },
  { path: 'anliegen', loadComponent: () => import('./pages/anliegen/anliegen.page') },
  {
    path: 'anliegen/:id/',
    loadComponent: () => import('./pages/anliegen/details/anliegen-details.page'),
  },
  { path: '**', component: StartseitePage },
];
